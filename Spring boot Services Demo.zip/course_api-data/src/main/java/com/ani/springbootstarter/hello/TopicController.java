package com.ani.springbootstarter.hello;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController

public class TopicController {
	
	@Autowired
	//private TopicService topicservices;
	
	
	
	
	
	public List<Topic> getAllTopics(){
		
		return Arrays.asList(new Topic("s12","java","java des"), new Topic("s2","spring","des"));
	}
	

	
	/*
	@RequestMapping("/topics")
	public List<Topic> getAllTopics() {
	
		
		return Arrays.asList(
				new Topic("s1", "Spring 1 ", "description 1"),
				new Topic("s2", "Spring 2 ", "description 2"),
				new Topic("s3", "Spring 3 ", "description 3")
				);
	}*/

	
	/*@RequestMapping("/topics")
		public ArrayList<Topic> getAllTopics(){
			
		return (ArrayList<Topic>) Arrays.asList(new Topic("s1", "spring", "des"));
		}
		*/
	

	}
